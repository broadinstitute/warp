#!/usr/bin/env python3
"""Which sites does the excess-heterozygosity filter remove that every other filter keeps,
and how much well-behaved variation is removed with them?

    python3 check_multiallelic_excess_het.py \\
        --aou-stats chrX.step1.aou.site_stats.tsv.bgz --anvil-stats chrX.step2.anvil.site_stats.tsv.bgz \\
        --filter-spec both.excess_het_f=-0.3,anvil.nonpar.min_avsad=6

Needs filter_sweep.py in the same folder (it supplies the filter logic, so the answer matches Step 3).
Local files or gs:// paths. Writes excess_het_only_sites.tsv and prints a summary.

A site counts as "lost to excess-het only" if it is kept when the excess-het test is switched off in
both cohorts and removed when it is on. For each such site the per-allele tests are listed, and an
allele is called a bystander if it does not fail the test itself, has |F| < --bystander-f and at
least --bystander-hets heterozygous carriers among the tested samples.
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import filter_sweep as fs


def numbers(x):
    return pd.to_numeric(pd.Series(str(x).split(",")), errors="coerce").values


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--aou-stats", required=True)
    ap.add_argument("--anvil-stats", required=True)
    ap.add_argument("--filter-spec", default="none")
    ap.add_argument("--bystander-hets", type=int, default=100)
    ap.add_argument("--bystander-f", type=float, default=0.1)
    ap.add_argument("--work-dir", default="site_stats")
    ap.add_argument("--out", default="excess_het_only_sites.tsv")
    args = ap.parse_args()

    aou, anvil = fs.read_stats(args.aou_stats, args.work_dir), fs.read_stats(args.anvil_stats, args.work_dir)
    spec_on = args.filter_spec
    spec_off = ("" if spec_on == "none" else spec_on + ",") + "both.excess_het_p=none"

    def kept(spec):
        thresholds, mode = fs.parse_filter_spec(spec)
        passes = fs.aou_pass(aou, thresholds["aou"], mode)
        excluded = fs.anvil_excluded_positions(anvil, thresholds["anvil"])
        return passes, np.isin(aou["pos"].values, excluded), thresholds

    pass_on, excl_on, thresholds = kept(spec_on)
    pass_off, excl_off, _ = kept(spec_off)
    lost = (pass_off & ~excl_off) & ~(pass_on & ~excl_on)
    by_aou = lost & ~pass_on                     # the AoU test removes the site
    by_anvil = lost & excl_on                    # the AnVIL test puts the position on the exclusion list

    print("filter spec: %s" % spec_on)
    print("AoU sites: %d; kept with the excess-het test off: %d; lost to excess-het only: %d"
          % (len(aou), (pass_off & ~excl_off).sum(), lost.sum()))
    print("  removed by the AoU test: %d   by the AnVIL test: %d   by both: %d"
          % ((by_aou & ~by_anvil).sum(), (by_anvil & ~by_aou).sum(), (by_aou & by_anvil).sum()))

    p_cut = {c: thresholds[c]["excess_het_p"] for c in ("aou", "anvil")}
    f_cut = {c: thresholds[c]["excess_het_f"] for c in ("aou", "anvil")}

    def cut(by_region, row, default):
        v = fs.region_thresholds(row, by_region)[0] if hasattr(fs, "region_thresholds") else default
        return default if np.isnan(v) else v

    anvil_by_pos = {}
    for i, pos in enumerate(anvil["pos"].values):
        anvil_by_pos.setdefault(pos, []).append(i)

    rows = []
    for i in np.flatnonzero(lost):
        r = aou.iloc[[i]]
        sources = []
        if by_aou[i]:
            sources.append(("aou", r))
        if by_anvil[i]:
            sources += [("anvil", anvil.iloc[[j]]) for j in anvil_by_pos.get(r["pos"].values[0], [])]
        for cohort, s in sources:
            p, f, het = numbers(s["eh_p"].values[0]), numbers(s["eh_f"].values[0]), numbers(s["eh_n_het"].values[0])
            pc = cut(p_cut[cohort], s, 3.4e-6)
            fc = cut(f_cut[cohort], s, np.inf)
            with np.errstate(invalid="ignore"):
                failing = (p < pc) & ((f < fc) if np.isfinite(fc) else True)
                bystander = ~failing & (np.abs(f) < args.bystander_f) & (het >= args.bystander_hets)
            if cohort == "anvil" and not failing.any():
                continue                         # an AnVIL row at this position that is not the cause
            rows.append(dict(contig=r["contig"].values[0], pos=int(r["pos"].values[0]), region=r["region"].values[0],
                             removed_by=cohort, ref=s["ref"].values[0], alts=s["alts"].values[0],
                             n_alt=len(p), n_failing=int(failing.sum()),
                             failing_hets=int(np.nansum(het[failing])), n_bystander=int(bystander.sum()),
                             bystander_hets=int(np.nansum(het[bystander])),
                             hets_per_allele=s["eh_n_het"].values[0], f_per_allele=",".join("%.2f" % x for x in f)))
    out = pd.DataFrame(rows)
    out.to_csv(args.out, sep="\t", index=False)
    if not len(out):
        print("no sites are lost to the excess-het test alone")
        return
    out["kind"] = np.where(out["n_alt"] > 1, "multiallelic", "biallelic")
    print("\nrows below are (site, cohort whose test fails); bystander = allele with |F| < %.2f and >= %d hets "
          "that does not fail itself" % (args.bystander_f, args.bystander_hets))
    summary = out.groupby(["removed_by", "region", "kind"]).agg(
        sites=("pos", "size"), with_bystander=("n_bystander", lambda x: int((x > 0).sum())),
        bystander_hets=("bystander_hets", "sum"), failing_hets=("failing_hets", "sum")).reset_index()
    print(summary.to_string(index=False))
    worst = out[out["n_bystander"] > 0].sort_values("bystander_hets", ascending=False).head(25)
    if len(worst):
        print("\nsites with the most bystander heterozygotes (full list in %s):" % args.out)
        print(worst[["pos", "region", "removed_by", "n_alt", "n_failing", "failing_hets", "bystander_hets",
                     "hets_per_allele", "f_per_allele"]].to_string(index=False, max_colwidth=60))


if __name__ == "__main__":
    main()
